<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use PdoForum;

class testController extends Controller
{
    function test($nomBD){
        
        return "Nombre de tables de la base de données : " . PdoForum::testNbtables($nomBD);
    } 
    
       
}
