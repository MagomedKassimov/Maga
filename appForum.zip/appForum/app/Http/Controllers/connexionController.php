<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use PdoForum;

class connexionController extends Controller
{
    function connecter(){
        
        return view('connexion')->with('erreurs',null);
    } 
    function valider(Request $request){
        $login = $request['login'];
        $mdp = $request['mdp'];
        $utilisateur = PdoForum::getInfosUtilisateur($login,$mdp);
        if(!is_array($utilisateur)){
            $erreurs[] = "Login ou mot de passe incorrect(s)";
            return view('connexion')->with('erreurs',$erreurs);
        }
        else{
            session(['for_utilisateurs' => $utilisateur]);
            return view('sommaire')->with('for_utilisateurs',session('for_utilisateurs'));
        }
    } 
    function deconnecter(){
            session(['for_utilisateurs' => null]);
            return redirect()->route('chemin_connexion');
       
           
    }
       
}
