    <?php $__env->startSection('menu'); ?>
            <!-- Division pour le sommaire -->
        <div id="menuGauche">
            <div id="infosUtil">
                  
             </div>  
               <ul id="menuList">
                   <li >
                    <strong>Bonjour <?php echo e($for_utilisateurs['auteur']); ?></strong>
                   </li>
                  
               <li class="smenu">
                <a href="<?php echo e(route('chemin_deconnexion')); ?>"" title="Se déconnecter">Déconnexion</a>
                  </li>
                </ul>
        </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('modeles/utilisateur', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>